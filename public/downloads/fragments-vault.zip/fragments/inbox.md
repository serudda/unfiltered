# Inbox

Unprocessed fragments. Use `/process-fragments` to categorize and move to library.

---

> "Do you love learning? Great, reframe it as 'research' and now that's literally your main job. Most of the things I write about simply come from learning about my interests and using social media as if I were 'taking notes in public'.
>
> (You're already investing time in learning, now just dedicate that time to learning in public and boom, you'll have the foundation of a business)."

**Source**: Dan Koe, Twitter/X
**Tags**: #build-in-public #learning #monetization
**Why**: We often learn things and simply don't share our findings. It stays between the source and me.
**Date**: 2026-01-13

---
