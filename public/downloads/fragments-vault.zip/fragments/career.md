# Career

Fragments about work, money, negotiation, employers, salaries, and professional growth.

---

