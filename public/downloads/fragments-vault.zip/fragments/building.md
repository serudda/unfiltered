# Building

Fragments about side projects, indie hacking, startups, and building in public.

---

